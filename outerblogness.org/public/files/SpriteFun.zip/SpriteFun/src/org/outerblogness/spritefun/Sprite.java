package org.outerblogness.spritefun;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.Log;

public class Sprite {

	Drawable myImage;
	
	// image bounding rectangle:
	int imageX;
	int imageY;
	int imageWidth;
	int imageHeight;
	
	public Sprite(Drawable image, int x, int y) {
        setCenter(x, y);
        myImage = image;
        imageWidth = 80 * SpriteFunGameView.scaling;
        imageHeight = 80 * SpriteFunGameView.scaling;
	}
	
	public boolean isInHitBox(int x, int y) {
		if(x < imageX) return false;
		if(x > imageX + imageWidth) return false;
		if(y < imageY) return false;
		if(y > imageY + imageHeight) return false;
		return true;
	}
	
	public boolean isTouching(Sprite sprite) {
		// Let's say they're touching if the middle of one is
		// in the other:
		int centerX = imageX + (imageWidth/2);
		int centerY = imageY + (imageHeight/2);
		return sprite.isInHitBox(centerX, centerY);
		
	}
	
	protected void draw(Canvas canvas) {
        myImage.setBounds(imageX, imageY, imageX + imageWidth, imageY + imageHeight);
		myImage.draw(canvas);      
    }
	
	protected void setTopLeftCorner(int x, int y) {
		imageX = x;
		imageY = y;
	}
	
	protected void setCenter(int x, int y) {
		imageX = x - (imageWidth/2);
		imageY = y - (imageHeight/2);
	}
		   
}
