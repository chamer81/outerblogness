package org.outerblogness.spritefun;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;

public class Button {
	
	// button bounding rectangle:
	float centerX;
	float centerY;
	int radius = 30 * SpriteFunGameView.scaling;
	
	// what color to make the button:
	int buttonColor;
	
	// the paint to use when painting the button:
	Paint buttonPaint = new Paint();
	
	public Button(float x, float y, int color) {
		// set the location:
		centerX = x;
		centerY = y;
		
		// set the color:
		buttonColor = color;
		buttonPaint.setStyle(Paint.Style.FILL);
		buttonPaint.setColor(buttonColor);
	}
	
	public boolean isInHitBox(int fingerX, int fingerY) {
		float deltaX = Math.abs(fingerX - centerX);
		float deltaY = Math.abs(fingerY - centerY);
		//Log.v("", "Is in button: fingerX: " + fingerX + "; fingerY: " + fingerY);
		//Log.v("", "Is in button: deltaX: " + deltaX + "; deltaY: " + deltaY);
		if(deltaX > radius) return false;
		if(deltaY > radius) return false;
		return true;
	}
	
	protected void draw(Canvas canvas) {
		canvas.drawCircle(centerX, centerY, radius, buttonPaint);
    }


}
