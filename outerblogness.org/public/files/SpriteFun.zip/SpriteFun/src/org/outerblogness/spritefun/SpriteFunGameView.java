package org.outerblogness.spritefun;

import java.util.LinkedList;
import java.util.List;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class SpriteFunGameView extends View {
	
	// for large screens:
	//public static int scaling = 2;
	// for small screens:
	public static int scaling = 1;
	
	// placeholders for important items:
	Sprite activeSprite;
	static Drawable currentAndroidImage;
	
	// sprites:
	Sprite eraser;
	List<Sprite> androids;
	
	// buttons:
	Button blueButton;
	Button redButton;
	Button greenButton;
	Button pinkButton;
	Button blackButton;
	Button whiteButton;

	// canvas boundaries:
	int canvasWidth;
	int canvasHeight;
	
	// sprite images:
	Drawable eraserImage;
	
	Drawable blackImage;
	Drawable blueImage;
	Drawable greenImage;
	Drawable pinkImage;
	Drawable redImage;
	Drawable whiteImage;

    public SpriteFunGameView(Context context, List<Sprite> sprites) {
        super(context);
        
        // set the list of androids:
        this.androids = sprites;
        
        // fetch the android images:
        Resources res = context.getResources();
		blackImage = res.getDrawable(R.drawable.blacky);
		blueImage = res.getDrawable(R.drawable.bluey);
		greenImage = res.getDrawable(R.drawable.greeny);
		pinkImage = res.getDrawable(R.drawable.pinky);
		redImage = res.getDrawable(R.drawable.redy);
		whiteImage = res.getDrawable(R.drawable.whitey);

        // Create the eraser sprite:
        eraserImage = res.getDrawable(R.drawable.eraser);
        this.eraser = new Sprite(eraserImage, 200 * scaling, 80 * scaling);
        
        // create the buttons:
    	blueButton = new Button(80.0f * scaling, 50.0f * scaling, 
    			Color.CYAN);
    	redButton = new Button(80.0f * scaling, 125.0f * scaling, 
    			Color.RED);
    	blackButton = new Button(80.0f * scaling, 200.0f * scaling, 
    			Color.BLACK);
    	greenButton = new Button(80.0f * scaling, 275.0f * scaling, 
    			Color.GREEN);
    	pinkButton = new Button(80.0f * scaling, 350.0f * scaling, 
    			Color.MAGENTA);
    	whiteButton = new Button(80.0f * scaling, 425.0f * scaling, 
    			Color.GRAY);
   }
    
   @Override
   protected void onDraw(Canvas canvas) {
      super.onDraw(canvas);
      canvasWidth = getWidth();
      canvasHeight = getHeight();
      
      // draw the buttons:
      blueButton.draw(canvas);
      redButton.draw(canvas);
      blackButton.draw(canvas);
      greenButton.draw(canvas);
      pinkButton.draw(canvas);
      whiteButton.draw(canvas);
      
      // draw the eraser:
      eraser.draw(canvas);
      
      // draw the androids:
	   for (Sprite android : androids) {
		   android.draw(canvas);
	   }
  }
   
   @Override
   public boolean onTouchEvent(MotionEvent event) {
	   // tell android to repaint the canvas
	   this.invalidate();
	   
	   // get the location of the touch:
	   int xPos = (int)event.getX();
	   int yPos = (int)event.getY();
	   
	   //Log.v("", "x: " + xPos);
	   //Log.v("", "y: " + yPos);
	   
	   int action = event.getAction();

	   if (action == MotionEvent.ACTION_DOWN) {
		   // the user touched the screen
		   Log.v("", "ACTION_DOWN");
		   
		   // the sprite the user touched becomes the 
		   // sprite that the user is controlling:
		   activeSprite = null;
		   for (Sprite android : androids) {
			   if(android.isInHitBox(xPos, yPos)) {
				   activeSprite = android;
			   }
		   }
		   if(eraser.isInHitBox(xPos, yPos)) {
			   activeSprite = eraser;
		   }
		   
		   // see if the user has pressed a button:
		   if(blueButton.isInHitBox(xPos, yPos)) {
			   currentAndroidImage = blueImage;
		   } else if(redButton.isInHitBox(xPos, yPos)) {
			   currentAndroidImage = redImage;
		   } else if(blackButton.isInHitBox(xPos, yPos)) {
			   currentAndroidImage = blackImage;
		   } else if(greenButton.isInHitBox(xPos, yPos)) {
			   currentAndroidImage = greenImage;
		   } else if(pinkButton.isInHitBox(xPos, yPos)) {
			   currentAndroidImage = pinkImage;
		   } else if(whiteButton.isInHitBox(xPos, yPos)) {
			   currentAndroidImage = whiteImage;
		   } else if((activeSprite == null) && (currentAndroidImage != null)){	   
		       // if the user didn't press a button and 
			   // didn't touch a sprite, make a new one:
			   activeSprite = new Sprite(currentAndroidImage, xPos, yPos);
			   androids.add(activeSprite);
		   }
		   
	   } else {
		   // move finger
		   Log.v("", "not ACTION_DOWN: " + action);
		   
		   // move the active sprite to the finger's new position:
		   if(activeSprite != null) {
			   activeSprite.setCenter(xPos, yPos);			   
		   }
		   
		   // check if any androids are touching the eraser
		   // and remove them from the list:
		   Sprite androidToErase = null;
		   for (Sprite android : androids) {
			   if(android.isTouching(eraser)) {
				   androidToErase = android;
			   }
		   }
		   if (androidToErase != null) {
			   androids.remove(androidToErase);
		   }
	   }

       return true;
   }
   
}
