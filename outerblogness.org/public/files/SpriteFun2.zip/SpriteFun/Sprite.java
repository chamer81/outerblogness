package org.outerblogness.spritefun;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;

import static org.outerblogness.spritefun.R.mipmap.greeny;

public class Sprite {

    Drawable myImage;

    // image bounding rectangle:
    int imageX;
    int imageY;
    int imageWidth;
    int imageHeight;

    public Sprite(Context context, int x, int y) {
        Resources res = context.getResources();
        myImage = res.getDrawable(greeny);
        setCenter(x, y);
        //imageWidth = myImage.getIntrinsicWidth();
        //imageHeight = myImage.getIntrinsicHeight();
        imageWidth = 144;
        imageHeight = 144;
    }

    protected boolean isInSprite(int x, int y) {
        if(x < imageX) return false;
        if(x > imageX + imageWidth) return false;
        if(y < imageY) return false;
        if(y > imageY + imageHeight) return false;
        return true;
    }

    protected void draw(Canvas canvas) {
        myImage.setBounds(imageX, imageY, imageX + imageWidth, imageY + imageHeight);
        myImage.draw(canvas);
    }

    protected void setTopLeftCorner(int x, int y) {
        imageX = x;
        imageY = y;
    }

    protected void setCenter(int x, int y) {
        imageX = x - (imageWidth/2);
        imageY = y - (imageHeight/2);
    }

}
