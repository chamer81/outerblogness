package org.outerblogness.spritefun;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Canvas;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class SpriteFunGameView extends View {

    Context context;
    Sprite activeSprite;

    List<Sprite> sprites = new ArrayList<Sprite>();

    // canvas boundaries:
    int canvasWidth;
    int canvasHeight;

    public SpriteFunGameView(Context context, List<Sprite> sprites) {
        super(context);
        this.context = context;
        this.sprites = sprites;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvasWidth = getWidth();
        canvasHeight = getHeight();

        for (Sprite sprite : sprites) {
            sprite.draw(canvas);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // tell android to repaint the canvas
        this.invalidate();

        // get the location of the touch:
        int xPos = (int)event.getX();
        int yPos = (int)event.getY();

        Log.v("", "x: " + xPos);
        Log.v("", "y: " + yPos);

        int action = event.getAction();
        if (action == MotionEvent.ACTION_DOWN) {
            Log.v("", "ACTION_DOWN");
            activeSprite = null;
            for (Sprite sprite : sprites) {
                if(sprite.isInSprite(xPos, yPos)) {
                    activeSprite = sprite;
                }
            }
            if(activeSprite == null) {
                activeSprite = new Sprite(context, xPos, yPos);
                sprites.add(activeSprite);
            }
        } else {
            Log.v("", "not ACTION_DOWN: " + action);
            if(activeSprite != null) {
                activeSprite.setCenter(xPos, yPos);
            }
        }

        return true;
    }

}
