package org.outerblogness.spritefun;

import java.util.ArrayList;
import java.util.List;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;


public class MainActivity extends AppCompatActivity {

    private SpriteFunGameView mSFGView;

    // the list of Sprites to display:
    // static to save them when the orientation changes:
    private static List<Sprite> sprites = new ArrayList<Sprite>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // comment out default:
        //setContentView(R.layout.activity_main);

        Log.v("", "in SpriteFun");
        // Create a SpriteFunGameView instance and set it
        // as the ContentView for this Activity.
        mSFGView = new SpriteFunGameView(this, sprites);
        setContentView(mSFGView);
    }
}
