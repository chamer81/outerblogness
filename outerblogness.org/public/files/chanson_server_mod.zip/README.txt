Chanson's silly server mod!!
http://outerblogness.org/files/chanson_server_mod.zip

Compatible with minecraft server 1.2.5 and no other mods!!

To install:

* Start with a new minecraft_server.jar file from minecraft.net
* copy all of the class files in this folder into your minecraft_server.jar


New features:
* bone meal applied to zombies turns them giant.
* shear creepers to turn them into villagers

New commands:
* /freebie to get one stack of a random quantity of a random type of items (once per minecraft day)
* /sethome and /home to set yourself a home and then teleport back to it
* /back to teleport back to your last teleport location
* /tr <username> to request teleport to another player (who can /accept or /reject)
* /ascend and /descend to teleport up and down (if there's somewhere to land)
